

rem nim2pc -2 -cFID_BERKELEY -FSANS_SERIF -o"Berkeley" Src/Berkeley/berkeley_09.mac Src/Berkeley/berkeley_10.mac Src/Berkeley/berkeley_12.mac Src/Berkeley/berkeley_14.mac Src/Berkeley/berkeley_18.mac

nim2pc -2 -n -u50 -cFID_DTC_PARK_AVENUE -FSCRIPT -o"Shattuck Avenue" Src/Park_Avenue/Park_Avenue.nim

